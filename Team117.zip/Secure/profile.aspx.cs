﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class Secure_profile :  System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        LabelInvisible.Text = Convert.ToInt32(Session["userID"]).ToString();
    }
}