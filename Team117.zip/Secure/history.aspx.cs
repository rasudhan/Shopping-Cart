﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using static DataSet;
using DataSetTableAdapters;
public partial class Secure_history :  System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Hashtable aTable = Session["userinfo"] as Hashtable;
        lblInvisible.Text = aTable["userID"].ToString();
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //Modified from https://forums.asp.net/t/1443686.aspx

                /* Get the value of the field that is going to determine what is disabled and what is enabled. */
                DateTime postDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "timestamp"));


        /* compare the value */
        TimeSpan ts = DateTime.Now - postDate;

                if ((double)ts.TotalHours > 24)
                {
                    /* find the control you want to disable or enable */
                    LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");
            Label sl = (Label)e.Row.FindControl("SentLabel");


                    /* check if control exists. */
                    if (lb != null)
                    {
                        /* enable/disable or do whatever you want with it */
                        lb.Visible = false;
                sl.Text = "SHIPPED";
                
                    }
                }
            }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridView1.Visible = true;
    }

    protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        GridView2.Visible = false;
    }

 


    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {
            int theID = Convert.ToInt32(e.CommandArgument);
      

                using(OrderItemTableAdapter oItem = new OrderItemTableAdapter())
                {
                    OrderItemDataTable theTable =  oItem.GetOrderItems(theID);

                    foreach(OrderItemRow aRow in theTable.Rows)
                    {
                        using (GameTableAdapter bAdapter = new GameTableAdapter())
                        {
                            bAdapter.AddStock(aRow.prodQty, aRow.gameID);
                        }

                    }

                    
                }

            using (OrderTableAdapter aAdapter = new OrderTableAdapter())
            {
                aAdapter.DeleteOrder(theID);
            }

        }
    }




}