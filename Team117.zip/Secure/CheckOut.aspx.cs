﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static DataSet;
using DataSetTableAdapters;
using System.Collections;

public partial class Secure_CheckOut : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["CustomerCart"] == null)
        {
            Session["CustomerCart"] = new ShopCart();
        }

        if ((Session["CustomerCart"] as ShopCart).GetCartItems().Count == 0)
        {
            btnPlaceOrder.Visible = false;
        }

        if (!Page.IsPostBack)
        {
            BindGrid();
        }
    }

    private void BindGrid()
    {
        gvCart.DataSource = (Session["CustomerCart"] as ShopCart).GetCartItems().Values;
        gvCart.DataBind();
    }

    protected void btnPlaceOrder_Click(object sender, EventArgs e)
    {
        int newOrderID;

        using (OrderTableAdapter aAdapt = new OrderTableAdapter())
        {
            //get userpk

            int intPK = Convert.ToInt32((Session["UserInfo"] as Hashtable)["userID"]);

            //Insert new order

            newOrderID = Convert.ToInt32(aAdapt.InsertOrder(intPK,OrderAmount()));
        }

        using (OrderItemTableAdapter oiAdapt = new OrderItemTableAdapter())
        {
            //Insert order details for the new order

            ShopCart aCart = Session["CustomerCart"] as ShopCart;
            foreach (CartItem aItem in aCart.GetCartItems().Values)
            {
                oiAdapt.InsertOrderItem(newOrderID, aItem.ProductID, aItem.Quantity);
                //oiAdapt.Insert( newOrderID, aItem.ProductID, aItem.Quantity);
                using(GameTableAdapter gAdapter = new GameTableAdapter())
                {
                    gAdapter.RemoveStock(aItem.Quantity, aItem.ProductID);
                }
            }

            //Remove all items from the cart

            aCart.DeleteAllCartItems();
        }

        if (Request.Cookies["SearchCriteria"] != null)
        {
            //Delete the SearchCriteria Cookie
            Response.Cookies["SearchCriteria"].Expires = DateTime.Now.AddDays(-1);
        }
        HttpCookie aCookie = new HttpCookie("ORDER");
        aCookie["oID"] = newOrderID.ToString();
        aCookie.Expires = DateTime.Now.AddMinutes(1);
        Response.Cookies.Add(aCookie);

        Server.Transfer("OrderConfirmation.aspx");
    }

    protected string OrderTotal()
    {
        ShopCart aCart = Session["CustomerCart"] as ShopCart;

        return string.Format("Your Order Total is: {0:c}", aCart.TotalForCartItems());
    }

    protected decimal OrderAmount()
    {
        ShopCart aCart = Session["CustomerCart"] as ShopCart;

        return aCart.TotalForCartItems();
    }

}