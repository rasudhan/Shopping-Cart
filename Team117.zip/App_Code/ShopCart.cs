﻿//Implementing a Shopping Cart; LV; November 2017
//Mangages a collection of CartItem objects

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class ShopCart
{
    private Dictionary<int, CartItem> CartItems;

    public ShopCart()
    {
        //instantiate cartitems object

        CartItems = new Dictionary<int, CartItem>();
    }

    public void AddCartItem( int ProductID, string ProductName, string ProductImageUrl, int Quantity, decimal Price, int Stock)
    {
        //If it is a new item

        if (!CartItems.ContainsKey(ProductID))
        {
            //Instantiate a new cartitem object

            CartItem aItem = new CartItem(ProductID, ProductName, ProductImageUrl, Quantity, Price, Stock);

            CartItems.Add(ProductID, aItem);
        }
        else
        {
            //Increase quantity by 1 if the current quantity is less than 'Stock'

            if (CartItems[ProductID].Quantity < Stock)
            {
                CartItems[ProductID].Quantity += 1;
            }
        }
    }

    public Dictionary<int, CartItem> GetCartItems()
    {
        return CartItems;
    }

    public void UpdateCartItem(int ProductID, int Quantity)
    {
        if (Quantity==0)
        {
            DeleteCartItem(ProductID);
        }
        else
        {
            CartItems[ProductID].Quantity = (Quantity <= CartItems[ProductID].Stock ? Quantity : CartItems[ProductID].Stock);
        }
    }

    public void DeleteCartItem(int ProductID)
    {
        CartItems.Remove(ProductID);
    }

    public void DeleteAllCartItems()
    {
        CartItems.Clear();
    }

    public decimal TotalForCartItems()
    {
        decimal Total = 0;

        foreach (CartItem aItem in CartItems.Values)
        {
            Total += (aItem.Price * aItem.Quantity);
        }

        return Total;
    }
}