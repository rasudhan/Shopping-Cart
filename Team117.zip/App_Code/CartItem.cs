﻿//Implementing a Shopping Cart; LV; November 2017
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class CartItem
{
    public int ProductID { get; set; }
    public int Quantity { get; set; }
    public string ProductName { get; set; }
    public string ProductImageUrl { get; set; }
    public decimal Price { get; set; }

    public int Stock { get; set; }

    public CartItem(int intProductID, string strProductName, string strProductImageUrl, int intQuantity, decimal decPrice, int prodStock)
    {
        ProductID = intProductID;
        ProductName = strProductName;
       this.ProductImageUrl = strProductImageUrl;
        Quantity = intQuantity;
        Price = decPrice;
        Stock = prodStock;
    }
}